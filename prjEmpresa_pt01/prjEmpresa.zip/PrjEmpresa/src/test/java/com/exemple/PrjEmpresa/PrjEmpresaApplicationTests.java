package com.exemple.PrjEmpresa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrjEmpresaApplicationTests {

	@Test
	void contextLoads() {
	}

}
