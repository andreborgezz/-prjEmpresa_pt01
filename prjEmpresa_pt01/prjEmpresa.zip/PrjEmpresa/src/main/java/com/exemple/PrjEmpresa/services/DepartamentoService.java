package com.exemple.PrjEmpresa.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.exemple.PrjEmpresa.entities.Departamento;
import com.exemple.PrjEmpresa.repositories.DepartamentoRepository;

public class DepartamentoService {

	private final DepartamentoRepository departamentoRepository;
	// metodo construtor da classe departamentoservice
		@Autowired
		public DepartamentoService(DepartamentoRepository departamentoRepository) {
			this.departamentoRepository = departamentoRepository;
		}
		//metodo criar um departamento
		public Departamento saveDepartamento(Departamento departamento) {
			return departamentoRepository.save(departamento);
		}
		//metodo pra buscar pelo id
		public Departamento getDepartamentoById(Long depnome) {
			return departamentoRepository.findById(depnome).orElse(null);
		}
		//metodo pra buscar tudo
		public List<Departamento> getAlldepartamento() {
			return departamentoRepository.findAll();
		}
		//metodo pra deletar
		public void deleteDepartamento(Long depnome) {
			departamentoRepository.deleteById(depnome);
		}
		//metodo pra atualizar
		public Departamento updateDepartamento(Long depnome, Departamento novoDepartamento) {
			Optional<Departamento> departamentoOptional = departamentoRepository.findById(depnome);
			if (departamentoOptional.isPresent()) {
				Departamento departamentoExistente = departamentoOptional.get();
				departamentoExistente.setDepcodigo(novoDepartamento.getDepcodigo());
				return departamentoRepository.save(departamentoExistente);
			} else {
				return null;
			}
		}

	}

