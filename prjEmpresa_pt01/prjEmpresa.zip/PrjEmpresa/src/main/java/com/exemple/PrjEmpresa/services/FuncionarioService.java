package com.exemple.PrjEmpresa.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.exemple.PrjEmpresa.entities.Funcionario;
import com.exemple.PrjEmpresa.repositories.FuncionarioRepository;

public class FuncionarioService {

	private final FuncionarioRepository funcionarioRepository;
	// metodo construtor da classe funcionarioservice
		@Autowired
		public FuncionarioService(FuncionarioRepository funcionarioRepository) {
			this.funcionarioRepository = funcionarioRepository;
		}
		//metodo criar um funcionario
		public Funcionario saveFuncionario(Funcionario funcionario) {
			return funcionarioRepository.save(funcionario);
		}
		//metodo pra buscar pelo id
		public Funcionario getFuncionarioById(Long funcodigo) {
			return funcionarioRepository.findById(funcodigo).orElse(null);
		}
		//metodo pra buscar tudo
		public List<Funcionario> getAllfuncionario() {
			return funcionarioRepository.findAll();
		}
		//metodo pra deletar
		public void deleteFuncionario(Long depnome) {
			funcionarioRepository.deleteById(depnome);
		}
		//metodo pra atualizar
		public Funcionario updateFuncionario(Long depnome, Funcionario novoFuncionario) {
			Optional<Funcionario> funcionarioOptional = funcionarioRepository.findById(depnome);
			if (funcionarioOptional.isPresent()) {
				Funcionario funcionarioExistente = funcionarioOptional.get();
				funcionarioExistente.setFuncodigo(novoFuncionario.getFuncodigo());
				return funcionarioRepository.save(funcionarioExistente);
			} else {
				return null;
			}
		}

	}

