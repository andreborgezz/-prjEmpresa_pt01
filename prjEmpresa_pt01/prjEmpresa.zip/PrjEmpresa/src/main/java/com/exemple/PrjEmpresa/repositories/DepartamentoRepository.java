package com.exemple.PrjEmpresa.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.exemple.PrjEmpresa.entities.Departamento;


	public interface DepartamentoRepository extends JpaRepository<Departamento, Long>{

	}

